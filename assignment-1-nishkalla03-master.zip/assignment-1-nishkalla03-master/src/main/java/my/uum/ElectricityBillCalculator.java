public class ElectricityBillCalculator extends ElectricityRecord {
    
    private static final double FIRST_BLOCK_RATE = 0.218;
    private static final double SECOND_BLOCK_RATE = 0.334;
    private static final double THIRD_BLOCK_RATE = 0.516;
    private static final double FOURTH_BLOCK_RATE = 0.546;
    private static final double FIFTH_BLOCK_RATE = 0.571;
    private static final double SST_RATE = 0.06;
    private static final double KWTBB_RATE = 0.016;

    private double bill;
    private double sst;
    private double kwtbb;
    private double totalBill;

    
    public ElectricityBillCalculator(String userId, String userName, int units) {
        super(userId, userName, units);
        calculateBill();
        calculateSST();
        calculateKWTBB();
        calculateTotalBill();
    }

    // Methods to calculate bill, SST, KWTBB, and total bill
    private void calculateBill() {
        if (units <= 200) {
            bill = units * FIRST_BLOCK_RATE;
        } else if (units <= 300) {
            bill = 200 * FIRST_BLOCK_RATE + (units - 200) * SECOND_BLOCK_RATE;
        } else if (units <= 600) {
            bill = 200 * FIRST_BLOCK_RATE + 100 * SECOND_BLOCK_RATE + (units - 300) * THIRD_BLOCK_RATE;
        } else if (units <= 900) {
            bill = 200 * FIRST_BLOCK_RATE + 100 * SECOND_BLOCK_RATE + 300 * THIRD_BLOCK_RATE + (units - 600) * FOURTH_BLOCK_RATE;
        } else {
            bill = 200 * FIRST_BLOCK_RATE + 100 * SECOND_BLOCK_RATE + 300 * THIRD_BLOCK_RATE + 300 * FOURTH_BLOCK_RATE + (units - 900) * FIFTH_BLOCK_RATE;
        }
    }

    private void calculateSST() {
        if (bill > 231.80) {
            sst = SST_RATE * bill;
        } else {
            sst = 0;
        }
    }

    private void calculateKWTBB() {
        kwtbb = KWTBB_RATE * bill;
    }

    private void calculateTotalBill() {
        totalBill = bill + sst + kwtbb;
    }

    // Getters for bill, SST, KWTBB, and total bill
    public double getBill() {
        return bill;
    }

    public double getSST() {
        return sst;
    }

    public double getKWTBB() {
        return kwtbb;
    }

    public double getTotalBill() {
        return totalBill;
    }
}
