public class ElectricityRecord {
    protected String userId;
    protected String userName;
    protected int units;

    public ElectricityRecord(String userId, String userName, int units) {
        this.userId = userId;
        this.userName = userName;
        this.units = units;
    }

    public String getUserId() {
        return userId;
    }

    public String getUserName() {
        return userName;
    }

    public int getUnits() {
        return units;
    }
}

