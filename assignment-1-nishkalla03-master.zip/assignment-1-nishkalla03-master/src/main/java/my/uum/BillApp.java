import java.util.Scanner;

public class BillApp {
    private static final Scanner scanner = new Scanner(System.in);
    private static final ElectricityBillCalculator[] records = new ElectricityBillCalculator[100];
    private static int recordCount = 0;

    public static void main(String[] args) {
        int choice;
        do {
            displayMainMenu(); // Display main menu
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addRecord(); 
                    break;
                case 2:
                    displayAllRecords(); 
                    break;
                case 3:
                    searchRecord(); 
                    break;
                case 4:
                    deleteRecord(); 
                    break;
                case 5:
                    System.out.println("Exiting..."); 
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        } while (choice != 5);
    }

// Methods for managing records
    private static void displayMainMenu() {
        System.out.println("=====================");
        System.out.println("Main Menu");
        System.out.println("=====================");
        System.out.println("1. Add Record");
        System.out.println("2. Display Record");
        System.out.println("3. Search Record");
        System.out.println("4. Delete Record");
        System.out.println("5. Exit");
        System.out.println("=====================");
    }

    private static void addRecord() {
        System.out.print("Enter number of records to add: ");
        int numRecords = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        for (int i = 0; i < numRecords; i++) {
            System.out.println("\nRecord " + (recordCount + 1) + " :");
            System.out.print("Input user id: ");
            String userId = scanner.nextLine();
            System.out.print("Input user name: ");
            String userName = scanner.nextLine();
            System.out.print("Number of units (kWj): ");
            int units = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            records[recordCount] = new ElectricityBillCalculator(userId, userName, units);
            recordCount++;
        }
    }

    private static void displayAllRecords() {
        System.out.println("==============================================");
        System.out.println("A list of user records\n");

        for (int i = 0; i < recordCount; i++) {
            System.out.println("Record " + (i + 1) + " :");
            System.out.println("Input user id: " + records[i].getUserId());
            System.out.println("Input user name: " + records[i].getUserName());
            System.out.println("Number of units (kWj): " + records[i].getUnits());
            System.out.println("Total Bill: " + records[i].getTotalBill());
            System.out.println("----------------------------------------------");
        }

        double totalBill = 0;
        for (int i = 0; i < recordCount; i++) {
            totalBill += records[i].getTotalBill();
        }
        System.out.println("Total electricity bill: RM " + totalBill);
        System.out.println("==============================================");
    }

    private static void searchRecord() {
        System.out.print("Enter a user id to be searched: ");
        String searchId = scanner.nextLine();

        boolean found = false;
        for (int i = 0; i < recordCount; i++) {
            if (records[i].getUserId().equals(searchId)) {
                found = true;
                System.out.println("\nThe data is found.\n");
                System.out.println("Input user id: " + records[i].getUserId());
                System.out.println("Input user name: " + records[i].getUserName());
                System.out.println("Number of units (kWj): " + records[i].getUnits());
                System.out.println("Total Bill: " + records[i].getTotalBill());
                break;
            }
        }

        if (!found) {
            System.out.println("Sorry, the data is not found.");
        }
        System.out.println("==============================================");
    }

    private static void deleteRecord() {
        System.out.print("Enter a user ID to be deleted: ");
        String deleteId = scanner.nextLine();

        for (int i = 0; i < recordCount; i++) {
            if (records[i].getUserId().equals(deleteId)) {
                System.out.println("The user ID " + deleteId + " has already been successfully deleted from the array of objects.");
                // Shift remaining records to fill the gap
                for (int j = i; j < recordCount - 1; j++) {
                    records[j] = records[j + 1];
                }
                recordCount--;
                break;
            }
        }

        System.out.println("==============================================");
    }
}

