[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/aLg0x4-V)
## Requirements for Assignment-1
1. [Read the instruction](https://github.com/STIA1123-A232/class-activity-stia1123/blob/main/Assignment-1.md)
1. [Read the Rubric](https://github.com/STIA1123-A232/class-activity-stia1123/blob/main/Rubric_Assignment-1.pdf)

## Your Info:
1. Matric Number : 299980 & Name : Nishkalla A/P Selva Ilangowan & Photo
   ![photo_6052866710282811199_y](https://github.com/STIA1123-A232/assignment-1-nishkalla03/assets/166980977/4d492fb6-63fb-4b9b-92b7-834f9eb6255e)

2. School : SOC & Programme : Bachelor of science with honours (Information technology)

## Result (Screenshot of the output)
![Screenshot 2024-05-09 183642](https://github.com/STIA1123-A232/assignment-1-nishkalla03/assets/166980977/96d1527f-de44-4c00-85bd-53ca6614cab1)
![Screenshot 2024-05-09 183655](https://github.com/STIA1123-A232/assignment-1-nishkalla03/assets/166980977/bb954b84-175a-4995-81b1-772b0bd36a5e)
![Screenshot 2024-05-09 183720](https://github.com/STIA1123-A232/assignment-1-nishkalla03/assets/166980977/5adb821c-5ca4-487d-999f-e4b573b4bc0f)
![Screenshot 2024-05-09 183732](https://github.com/STIA1123-A232/assignment-1-nishkalla03/assets/166980977/74155f17-15ac-4562-bdd4-47417c40ee38)

## UML Diagram
![Screenshot 2024-05-09 185550](https://github.com/STIA1123-A232/assignment-1-nishkalla03/assets/166980977/3c9d577a-5fff-447b-b24b-86ce7351150e)

## Youtube Presentation
https://youtu.be/BzdXEdu2zPY?si=zF62P4qvjFeHXDEo
